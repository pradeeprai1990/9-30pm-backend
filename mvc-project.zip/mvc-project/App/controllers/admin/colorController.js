let colorController = {
  create: (req, res) => {
    //DataBase Insert
    res.send({
      status: true,
      message: "colorController Color Addred",
    });
  },
  view: (req, res) => {
    res.send({
      status: true,
      message: "Color View",
    });
  },
  delete: (req, res) => {
    res.send({
      status: true,
      message: "Color Delete",
    });
  },
  update: (req, res) => {
    res.send({
      status: true,
      message: "Color Updated",
    });
  },
  changeStatus: (req, res) => {
    res.send({
      status: true,
      message: "Color Status Changed",
    });
  },
};

module.exports = colorController;
