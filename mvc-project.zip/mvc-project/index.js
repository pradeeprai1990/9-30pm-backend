let express=require("express");
require("dotenv").config() //
const adminRoutes = require("./App/routes/admin/adminRoutes");
const checkToken = require("./App/middleware/checkToken");
let App=express()


// console.log(process.env.TOKEN); //12345

//http://localhost:8000/admin
//  App.use(checkToken) //next

App.use("/admin",adminRoutes) //adminRoutes Call



//http://localhost:8000
App.listen(8000,()=>{
    console.log("Server Start");
    
})